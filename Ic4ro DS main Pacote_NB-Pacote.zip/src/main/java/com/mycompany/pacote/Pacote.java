/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pacote;

import com.mycompany.pacote.view.LoginView;

/**
 *
 * @author aluno.den
 */
public class Pacote {

    public static void main(String[] args) {
        LoginView loginView = new LoginView();
        loginView.setVisible(true);
        
    }
}
